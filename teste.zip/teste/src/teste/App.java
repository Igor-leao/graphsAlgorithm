package teste;

import java.io.*;
import java.util.*;



public class App {
  
  private static ArrayList<int[]> allPermutations = new ArrayList<>();
  private static int cont = 0;
  private static int[] permutation;

    public static void main(String[] args) throws IOException {
        Scanner read = new Scanner(System.in);
        
        File file = new File("graph.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        String line = " ";

        line = br.readLine();
        int vertices = Integer.parseInt(line);
        line = br.readLine();        

        byte[][] matrix = new byte[vertices][vertices];
        adjacencyMatrix(matrix, vertices, line, br);
  
        printGraphs(read, matrix, vertices);

        getCyclesThroughPermutation(matrix, vertices); 
        
        ciclesinMatrix(matrix, vertices);

        read.close();
    }

    public static void getCyclesThroughPermutation(byte[][] matrix, int vertices){
        
        allPermutations = new ArrayList<>();

        int allVertices[] = new int[vertices];

        int value = 0;
        for (int i = 0; i < vertices; i++){
            value++;
            allVertices[i] = value;
        } 
        startPermute(allVertices);
    }


    public static void startPermute(int[] vertices) {

      System.out.println("todas as permutações");
        for (int i = 3; i < 4; i++){
            permutation = new int[i];
            permute(vertices, 0, allPermutations);
        }
        System.out.println("permutações com repetições");

        for (int i = 0; i < allPermutations.size(); i++){
          System.out.println("\n");
            for (int j = 0; j < allPermutations.get(i).length; j++){
                System.out.print(allPermutations.get(i)[j]);
            }
        }
    }


    private static void permute(int[] vertices, int n, ArrayList<int[]> allPermutations) {

        if (n == permutation.length) {
            cont++;

             System.out.print("Permutação normal:");
             for (int i=0; i < permutation.length; i++) System.out.print(permutation[i] + " ");
            
            int[] clone = permutation.clone();
            Arrays.sort(clone);

            if(!allPermutations.contains(clone)){
                allPermutations.add(permutation);
                printPermutation();
            }


        } else {
            for (int i=0; i < vertices.length; i++) {
                boolean found = false;
                for (int j = 0; j < n; j++) {
                    if (permutation[j]==vertices[i]) found = true;
                }
                if (!found) {
                    permutation[n] = vertices[i];
                    permute(vertices, n+1, allPermutations);
                }
            }
        }
    }

 public static void ciclesinMatrix(byte [][]matrix, int vertices){
int[] aux = new int[vertices];
System.out.println("cheguei aqui");
int a = 0, b = 0, c = 0;

for (int i = 0; i < vertices; i++){
  int x = 0;
    for (int j = 0; j < vertices; j++){
     
         if(matrix[i][j] == 1 && a == 1) {
            b = i;
            c = j;
            System.out.println("primeiro if pra conferir");
            System.out.println("b" + b);
            System.out.println("c" + c);
        } if (matrix[c][b] == 1) {
          System.out.println("segundo if pra conferir");
          System.out.println("b" + b);
          System.out.println("c" + c);
          
        }
         else {
          a ++; 
        }
    }
}

//int [] b = new int[a *2];
//int [] c = new int[a * 2];
//for (int i = 0; i < vertices; i++){
//  for (int j = 0; j < vertices; j++){
//       if(matrix[i][j] == 1) {
//         b[]
//
//      }
//  }
//}

 }

    private static void printPermutation() {
        System.out.println();
        System.out.print("(" + cont + ") : ");
        for (int i=0; i < permutation.length; i++) System.out.print(permutation[i] + " ");
    }

    public static void adjacencyMatrix(byte[][] adjMatrix, int vertices, String lineRead, BufferedReader br) throws IOException  {

        for (int row = 0; row < vertices; row++){
            for (int column = 0; column < vertices; column++){
                adjMatrix[row][column] = 0;
            }
        }

        lineRead = br.readLine();

        while(lineRead != null){
            String regexEdges = " ";
            String[] slicedEdges = lineRead.split(regexEdges);

            int row = Integer.parseInt(slicedEdges[0]); 
            int column = Integer.parseInt(slicedEdges[1]);

            adjMatrix[row - 1][column - 1] = 1;
            adjMatrix[column - 1][row - 1] = 1;

            lineRead = br.readLine();
        }
    }

    public static void printGraphs(Scanner read, byte[][] matrix, int vertices){
      
      System.out.println("matriz");
            for (int i = 0; i < vertices; i++){
                for (int j = 0; j < vertices; j++){
                    System.out.print(matrix[i][j] + "  ");
                }
                System.out.print("\n");
            }
    }

}